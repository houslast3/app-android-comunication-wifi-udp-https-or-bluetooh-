#include <WiFi.h>
#include <WiFiUdp.h>
#include <HTTPClient.h>
#include <Preferences.h>
#include <ArduinoJson.h>
#include <SensirionI2cSps30.h>
#include <Wire.h>
#include <time.h>
#include <math.h>
#include <TinyGPS++.h>
#include <WebServer.h>

#define UDP_PORT      8888
#define HTTP_PORT     80

const char* TAGO_URL = "https://api.tago.io/data";
#define MAX_BUFFER 500
const int READ_INTERVAL_MS = 2000;
const int WIFI_MAX_ATTEMPTS = 5;
const unsigned long WIFI_ATTEMPT_TIMEOUT_MS = 5000;
const unsigned long PHONE_GPS_TIMEOUT = 15000;

const char* AP_SSID = "ParticulaGPS";
const char* AP_PASS = "";

const char* PREF_WIFI = "wifi";
const char* PREF_SSID = "ssid";
const char* PREF_PASS = "pass";
const char* PREF_CFG = "config";
const char* PREF_BUFSIZE = "bufsize";
const char* PREF_DIST = "dist";

const char* NTP_SERVER = "pool.ntp.org";
const long GMT_OFFSET = -3 * 3600;
const int DST_OFFSET = 0;

const uint8_t I2C_ADDRS[] = {SPS30_I2C_ADDR_69, 0x68, 0x6A};

#define GPS_RX    26
#define GPS_TX    25
#define GPS_PWR   13

struct SensorReading {
  float pm1p0, pm2p5, pm10p0, lat, lng;
  String timeStr;
};

struct GpsData {
  bool   fixOK = false;
  double latitude = 0, longitude = 0;
  int    satellitesUsed = 0;
  float  hdop = 0;
  int    satellitesInView = 0, maxSignalStrength = 0;
};

SensirionI2cSps30 sps30;
Preferences prefs;
WiFiUDP udp;
WebServer httpServer(HTTP_PORT);

SensorReading buffer[MAX_BUFFER];
int bufferIndex = 0;
bool bufferReady = false;
unsigned long lastReadTime = 0;

String configTagoToken = "8d97b01c-4235-41f9-9e1a-6e56ec85a764";
int configBufferSize = 60;
int configDistanceThreshold = 100;
int configTimeInterval = 60;
String configMode = "distance";

float lastBufferedLat = 0, lastBufferedLng = 0;
bool hasLastBufferedPos = false;
unsigned long lastBufferTime = 0;

float currentPm1p0 = 0, currentPm2p5 = 0, currentPm10p0 = 0;
float currentLat = 0, currentLng = 0;
bool hasGps = false;
int currentSats = 0, currentSatsInView = 0;
float currentHdop = 0;
int currentSignalMax = 0;
bool sensorReady = false;
bool apMode = false;
String wifiStatus = "Desconectado";
String localIp = "0.0.0.0";

bool useInternalGps = true;
bool phoneGpsReceived = false;
float phoneLat = 0, phoneLng = 0, phoneSpeed = 0;
unsigned long lastPhoneGpsTime = 0;

bool tagoConnected = false;
String tagoLastResponse = "";
int tagoSuccessCount = 0, tagoFailCount = 0;

bool hasPhoneContact = false;
String phoneIp = "";
int phonePort = 0;
unsigned long lastPhoneContactTime = 0;

TinyGPSPlus gps;
HardwareSerial gpsSerial(2);
String linhaNMEA = "";
GpsData gpsData;
SemaphoreHandle_t gpsMutex = NULL;

unsigned long lastDiscoveryBroadcast = 0;
const unsigned long DISCOVERY_INTERVAL = 3000;
const unsigned long PHONE_CONTACT_TIMEOUT = 30000;
unsigned long lastContactTime = 0;

void initGPS();
void readGPS();
void setupSensor();
void readSensor();
void setupWiFi();
bool tryConnectWiFi(const String& ssid, const String& pass);
void startAP();
void setupNTP();
void loadConfig();
void saveConfig();
void handleUdp();
void broadcastDiscovery();
void addToBuffer();
void sendToTagoIO();
float calcDistance(float lat1, float lng1, float lat2, float lng2);
String timeToString(time_t t);
String getUptime();
String jsonEscape(String s);
void handleApRoot();
void handleApSave();
void startHttpServer();
void handleApiStatus();
void handleApiConfig();
void handleApiConfigPost();
void handleApiGps();
void handleApiPing();
void sendCORS();
void sendJson(int code, const String& json);
String buildStatusJson();

void setup() {
  Serial.begin(115200);
  Serial.println("\n=== ParticulaGPS v2 Discovery ===");

  Wire.begin(21, 22);
  Wire.setClock(100000);

  setupSensor();
  initGPS();
  loadConfig();
  setupWiFi();
  setupNTP();

  udp.begin(UDP_PORT);
  Serial.printf("UDP %d\n", UDP_PORT);

  startHttpServer();

  lastReadTime = millis();
  lastDiscoveryBroadcast = millis();
}

void loop() {
  httpServer.handleClient();

  unsigned long now = millis();

  static unsigned long lastGpsRead = 0;
  if (now - lastGpsRead >= 1000) {
    lastGpsRead = now;
    readGPS();

    if (useInternalGps) {
      if (gpsMutex && xSemaphoreTake(gpsMutex, portMAX_DELAY)) {
        currentLat = (float)gpsData.latitude;
        currentLng = (float)gpsData.longitude;
        hasGps = gpsData.fixOK;
        currentSats = gpsData.satellitesUsed;
        currentSatsInView = gpsData.satellitesInView;
        currentHdop = gpsData.hdop;
        currentSignalMax = gpsData.maxSignalStrength;
        xSemaphoreGive(gpsMutex);
      }
    } else {
      if (phoneGpsReceived && now - lastPhoneGpsTime < PHONE_GPS_TIMEOUT) {
        currentLat = phoneLat;
        currentLng = phoneLng;
        hasGps = true;
      } else {
        hasGps = false;
      }
    }

    if (hasGps) {
      if (!hasLastBufferedPos) {
        addToBuffer();
        lastBufferTime = now;
      } else if (configMode == "time") {
        if (now - lastBufferTime >= (unsigned long)configTimeInterval * 1000) {
          addToBuffer();
          lastBufferTime = now;
        }
      } else {
        float dist = calcDistance(lastBufferedLat, lastBufferedLng, currentLat, currentLng);
        if (dist >= configDistanceThreshold) {
          addToBuffer();
          lastBufferTime = now;
        }
      }
    }
  }

  if (now - lastReadTime >= READ_INTERVAL_MS) {
    lastReadTime = now;
    readSensor();
  }

  handleUdp();

  if (hasPhoneContact && now - lastContactTime > PHONE_CONTACT_TIMEOUT) {
    hasPhoneContact = false;
    phoneGpsReceived = false;
    Serial.println("Phone timeout - rediscovery");
  }

  if (!hasPhoneContact && !apMode && now - lastDiscoveryBroadcast >= DISCOVERY_INTERVAL) {
    lastDiscoveryBroadcast = now;
    broadcastDiscovery();
  }

  if (bufferReady) {
    sendToTagoIO();
    bufferReady = false;
    bufferIndex = 0;
    hasLastBufferedPos = false;
  }
}

void startHttpServer() {
  httpServer.on("/api/status", HTTP_GET, handleApiStatus);
  httpServer.on("/api/config", HTTP_GET, handleApiConfig);
  httpServer.on("/api/config", HTTP_POST, handleApiConfigPost);
  httpServer.on("/api/gps", HTTP_POST, handleApiGps);
  httpServer.on("/api/ping", HTTP_POST, handleApiPing);
  httpServer.on("/api/ping", HTTP_GET, handleApiPing);

  if (apMode) {
    httpServer.on("/", handleApRoot);
    httpServer.on("/save", handleApSave);
  }

  httpServer.begin();
  Serial.printf("HTTP %d\n", HTTP_PORT);
}

void sendCORS() {
  httpServer.sendHeader("Access-Control-Allow-Origin", "*");
  httpServer.sendHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  httpServer.sendHeader("Access-Control-Allow-Headers", "Content-Type");
}

void sendJson(int code, const String& json) {
  sendCORS();
  httpServer.send(code, "application/json", json);
}

String buildStatusJson() {
  String j = "{";
  j += "\"type\":\"status\"";
  j += ",\"pm1\":" + String(currentPm1p0, 2);
  j += ",\"pm2p5\":" + String(currentPm2p5, 2);
  j += ",\"pm10p0\":" + String(currentPm10p0, 2);
  j += ",\"lat\":" + String(currentLat, 6);
  j += ",\"lng\":" + String(currentLng, 6);
  j += ",\"gps\":" + String(hasGps ? "true" : "false");
  j += ",\"sats\":" + String(currentSats);
  j += ",\"hdop\":" + String(currentHdop, 1);
  j += ",\"buffer\":" + String(bufferIndex);
  j += ",\"bufSize\":" + String(configBufferSize);
  j += ",\"tagoOk\":" + String(tagoSuccessCount);
  j += ",\"tagoFail\":" + String(tagoFailCount);
  j += ",\"uptime\":\"" + getUptime() + "\"";
  j += ",\"useInternalGps\":" + String(useInternalGps ? "true" : "false");
  j += ",\"phoneGps\":" + String(phoneGpsReceived ? "true" : "false");
  j += ",\"mode\":\"" + configMode + "\"";
  j += "}";
  return j;
}

void handleApiStatus() { sendJson(200, buildStatusJson()); }

void handleApiConfig() {
  String j = "{";
  j += "\"type\":\"config\"";
  j += ",\"bufSize\":" + String(configBufferSize);
  j += ",\"distance\":" + String(configDistanceThreshold);
  j += ",\"timeInt\":" + String(configTimeInterval);
  j += ",\"mode\":\"" + configMode + "\"";
  j += ",\"tagotoken\":\"" + jsonEscape(configTagoToken) + "\"";
  j += ",\"useInternalGps\":" + String(useInternalGps ? "true" : "false");
  j += "}";
  sendJson(200, j);
}

void handleApiConfigPost() {
  if (!httpServer.hasArg("plain")) { sendJson(400, "{\"error\":\"no body\"}"); return; }
  String body = httpServer.arg("plain");
  StaticJsonDocument<512> doc;
  if (deserializeJson(doc, body)) { sendJson(400, "{\"error\":\"invalid json\"}"); return; }

  if (doc.containsKey("tagotoken")) configTagoToken = doc["tagotoken"].as<String>();
  if (doc.containsKey("bufSize")) configBufferSize = constrain(doc["bufSize"].as<int>(), 5, MAX_BUFFER);
  if (doc.containsKey("distance")) configDistanceThreshold = constrain(doc["distance"].as<int>(), 10, 1000);
  if (doc.containsKey("timeInt")) configTimeInterval = constrain(doc["timeInt"].as<int>(), 10, 3600);
  if (doc.containsKey("mode")) { String m = doc["mode"].as<String>(); if (m == "distance" || m == "time") configMode = m; }
  if (doc.containsKey("useInternalGps")) useInternalGps = doc["useInternalGps"].as<bool>();

  saveConfig();
  if (bufferIndex >= configBufferSize) bufferReady = true;
  if (!hasPhoneContact) hasPhoneContact = true;
  lastContactTime = millis();

  String j = "{\"success\":true}";
  sendJson(200, j);
}

void handleApiGps() {
  if (!httpServer.hasArg("plain")) { sendJson(400, "{\"error\":\"no body\"}"); return; }
  String body = httpServer.arg("plain");
  StaticJsonDocument<256> doc;
  if (deserializeJson(doc, body)) { sendJson(400, "{\"error\":\"invalid json\"}"); return; }

  phoneLat = doc["lat"] | 0.0f;
  phoneLng = doc["lng"] | 0.0f;
  phoneSpeed = doc["speed"] | 0.0f;
  phoneGpsReceived = true;
  lastPhoneGpsTime = millis();
  if (!hasPhoneContact) hasPhoneContact = true;
  lastContactTime = millis();

  if (!useInternalGps) { currentLat = phoneLat; currentLng = phoneLng; hasGps = true; }
  sendJson(200, "{\"success\":true}");
}

void handleApiPing() {
  if (!hasPhoneContact) hasPhoneContact = true;
  lastContactTime = millis();
  String j = "{";
  j += "\"type\":\"pong\",\"ip\":\"" + localIp + "\"";
  j += ",\"uptime\":\"" + getUptime() + "\"";
  j += ",\"pm2p5\":" + String(currentPm2p5, 2);
  j += ",\"gps\":" + String(hasGps ? "true" : "false");
  j += ",\"lat\":" + String(currentLat, 6);
  j += ",\"lng\":" + String(currentLng, 6);
  j += "}";
  sendJson(200, j);
}

// ================== UDP DISCOVERY ==================

void broadcastDiscovery() {
  String j = "{";
  j += "\"type\":\"discover\"";
  j += ",\"name\":\"ParticulaGPS\"";
  j += ",\"ip\":\"" + localIp + "\"";
  j += ",\"port\":" + String(HTTP_PORT);
  j += ",\"sensor\":" + String(sensorReady ? "true" : "false");
  j += ",\"gps\":" + String(hasGps ? "true" : "false");
  j += ",\"lat\":" + String(currentLat, 6);
  j += ",\"lng\":" + String(currentLng, 6);
  j += ",\"pm2p5\":" + String(currentPm2p5, 2);
  j += ",\"bufSize\":" + String(configBufferSize);
  j += "}";

  udp.beginPacket("255.255.255.255", UDP_PORT);
  udp.print(j);
  udp.endPacket();
}

void handleUdp() {
  int packetSize = udp.parsePacket();
  if (!packetSize) return;

  char buf[2048];
  int len = udp.read(buf, sizeof(buf) - 1);
  if (len <= 0) return;
  buf[len] = '\0';

  String msg = String(buf);
  String remoteIp = udp.remoteIP().toString();
  int remotePort = udp.remotePort();

  StaticJsonDocument<1024> doc;
  if (deserializeJson(doc, msg)) return;

  const char* type = doc["type"];
  if (!type) return;

  // Qualquer pacote valido do phone = contato estabelecido
  if (!hasPhoneContact) {
    hasPhoneContact = true;
    phoneIp = remoteIp;
    phonePort = remotePort;
    Serial.printf("Phone: %s:%d\n", phoneIp.c_str(), phonePort);
  }
  lastContactTime = millis();

  if (strcmp(type, "gps") == 0) {
    phoneLat = doc["lat"] | 0.0f;
    phoneLng = doc["lng"] | 0.0f;
    phoneSpeed = doc["speed"] | 0.0f;
    phoneGpsReceived = true;
    lastPhoneGpsTime = millis();
    if (!useInternalGps) { currentLat = phoneLat; currentLng = phoneLng; hasGps = true; }
    return;
  }

  if (strcmp(type, "config") == 0) {
    if (doc.containsKey("tagotoken")) configTagoToken = doc["tagotoken"].as<String>();
    if (doc.containsKey("bufSize")) configBufferSize = constrain(doc["bufSize"].as<int>(), 5, MAX_BUFFER);
    if (doc.containsKey("distance")) configDistanceThreshold = constrain(doc["distance"].as<int>(), 10, 1000);
    if (doc.containsKey("timeInt")) configTimeInterval = constrain(doc["timeInt"].as<int>(), 10, 3600);
    if (doc.containsKey("mode")) { String m = doc["mode"].as<String>(); if (m == "distance" || m == "time") configMode = m; }
    if (doc.containsKey("useInternalGps")) useInternalGps = doc["useInternalGps"].as<bool>();
    saveConfig();
    if (bufferIndex >= configBufferSize) bufferReady = true;
    String resp = "{\"type\":\"config_ack\",\"success\":true}";
    udp.beginPacket(udp.remoteIP(), udp.remotePort());
    udp.print(resp);
    udp.endPacket();
    return;
  }

  if (strcmp(type, "ping") == 0) {
    String resp = "{\"type\":\"pong\",\"ip\":\"" + localIp + "\"}";
    udp.beginPacket(udp.remoteIP(), udp.remotePort());
    udp.print(resp);
    udp.endPacket();
    return;
  }

  if (strcmp(type, "settings") == 0 && apMode) {
    String ssid = doc["wifiSsid"].as<String>();
    String pass = doc["wifiPass"].as<String>();
    if (ssid.length() > 0) {
      prefs.begin(PREF_WIFI, false);
      prefs.putString(PREF_SSID, ssid);
      prefs.putString(PREF_PASS, pass);
      prefs.end();
      String resp = "{\"type\":\"settings_ack\",\"success\":true}";
      udp.beginPacket(udp.remoteIP(), udp.remotePort());
      udp.print(resp);
      udp.endPacket();
      delay(500);
      ESP.restart();
    }
    return;
  }
}

// ================== CONFIG ==================

void loadConfig() {
  prefs.begin(PREF_CFG, false);
  configBufferSize = constrain(prefs.getInt(PREF_BUFSIZE, 60), 5, MAX_BUFFER);
  configDistanceThreshold = constrain(prefs.getInt(PREF_DIST, 100), 10, 1000);
  configTimeInterval = constrain(prefs.getInt("timeint", 60), 10, 3600);
  configMode = prefs.getString("mode", "distance");
  if (configMode != "distance" && configMode != "time") configMode = "distance";
  configTagoToken = prefs.getString("tagotoken", "8d97b01c-4235-41f9-9e1a-6e56ec85a764");
  useInternalGps = prefs.getBool("intgps", true);
  prefs.end();
}

void saveConfig() {
  prefs.begin(PREF_CFG, false);
  prefs.putInt(PREF_BUFSIZE, configBufferSize);
  prefs.putInt(PREF_DIST, configDistanceThreshold);
  prefs.putInt("timeint", configTimeInterval);
  prefs.putString("mode", configMode);
  prefs.putString("tagotoken", configTagoToken);
  prefs.putBool("intgps", useInternalGps);
  prefs.end();
}

// ================== GPS ==================

void initGPS() {
  pinMode(GPS_PWR, OUTPUT);
  digitalWrite(GPS_PWR, HIGH);
  delay(100);
  gpsSerial.begin(9600, SERIAL_8N1, GPS_RX, GPS_TX);
  if (gpsMutex == NULL) gpsMutex = xSemaphoreCreateMutex();
}

void readGPS() {
  int localSv = -1, localSig = -1;
  bool localFix = false;
  double localLat = 0, localLng = 0;
  int localSat = 0;
  float localHdop = 0;

  while (gpsSerial.available() > 0) {
    char c = gpsSerial.read();
    gps.encode(c);

    if (c == '\n') {
      if (linhaNMEA.startsWith("$GPGSV") || linhaNMEA.startsWith("$GLGSV")) {
        int p3 = -1, p4 = -1, pos = 0;
        for (int i = 0; i < 4; i++) {
          pos = linhaNMEA.indexOf(',', pos);
          if (pos == -1) break;
          if (i == 2) p3 = pos;
          if (i == 3) p4 = pos;
          pos++;
        }
        if (p3 != -1 && p4 != -1) {
          int sv = linhaNMEA.substring(p3 + 1, p4).toInt();
          if (sv > 0) {
            int ast = linhaNMEA.indexOf('*');
            int lc = linhaNMEA.lastIndexOf(',');
            if (ast != -1 && lc > p4) {
              int sig = linhaNMEA.substring(lc + 1, ast).toInt();
              if (sv > localSv) localSv = sv;
              if (sig > localSig) localSig = sig;
            }
          }
        }
      }
      linhaNMEA = "";
    } else if (c != '\r') {
      linhaNMEA += c;
    }
  }

  if (gps.location.isValid()) {
    localFix = true;
    localLat = gps.location.lat();
    localLng = gps.location.lng();
    localSat = gps.satellites.isValid() ? gps.satellites.value() : 0;
    localHdop = gps.hdop.isValid() ? gps.hdop.hdop() : 0;
  }

  if (gpsMutex && xSemaphoreTake(gpsMutex, portMAX_DELAY)) {
    gpsData.fixOK = localFix;
    gpsData.latitude = localLat;
    gpsData.longitude = localLng;
    gpsData.satellitesUsed = localSat;
    gpsData.hdop = localHdop;
    if (localSv >= 0) gpsData.satellitesInView = localSv;
    if (localSig >= 0 && localSig > gpsData.maxSignalStrength)
      gpsData.maxSignalStrength = localSig;
    xSemaphoreGive(gpsMutex);
  }
}

// ================== SENSOR SPS30 ==================

void setupSensor() {
  for (uint8_t addr : I2C_ADDRS) {
    sps30.begin(Wire, addr);
    int16_t error = sps30.stopMeasurement();
    delay(50);
    if (error == 0) {
      error = sps30.startMeasurement(SPS30_OUTPUT_FORMAT_OUTPUT_FORMAT_FLOAT);
      if (error == 0) { sensorReady = true; Serial.printf("SPS30 0x%x\n", addr); return; }
    }
  }
  Serial.println("SPS30 NAO");
}

void readSensor() {
  if (!sensorReady) return;
  uint16_t readyFlag = 0;
  float mc1p0, mc2p5, mc4p0, mc10p0, nc0p5, nc1p0, nc2p5, nc4p0, nc10p0, typicalSize;
  if (sps30.readDataReadyFlag(readyFlag) != 0 || readyFlag == 0) return;
  if (sps30.readMeasurementValuesFloat(mc1p0, mc2p5, mc4p0, mc10p0, nc0p5, nc1p0, nc2p5, nc4p0, nc10p0, typicalSize) == 0) {
    currentPm1p0 = mc1p0;
    currentPm2p5 = mc2p5;
    currentPm10p0 = mc10p0;
  }
}

// ================== WIFI ==================

void setupWiFi() {
  prefs.begin(PREF_WIFI, false);
  String savedSSID = prefs.getString(PREF_SSID, "");
  String savedPass = prefs.getString(PREF_PASS, "");
  prefs.end();

  if (savedSSID.length() > 0) {
    Serial.print("WiFi " + savedSSID);
    if (tryConnectWiFi(savedSSID, savedPass)) {
      apMode = false;
      wifiStatus = "Conectado";
      localIp = WiFi.localIP().toString();
      Serial.printf(" OK %s\n", localIp.c_str());
      return;
    }
    Serial.println(" falha");
  }
  startAP();
}

bool tryConnectWiFi(const String& ssid, const String& pass) {
  WiFi.mode(WIFI_STA);
  WiFi.begin(ssid.c_str(), pass.c_str());
  for (int i = 0; i < WIFI_MAX_ATTEMPTS; i++) {
    delay(WIFI_ATTEMPT_TIMEOUT_MS);
    if (WiFi.status() == WL_CONNECTED) return true;
  }
  return WiFi.status() == WL_CONNECTED;
}

void startAP() {
  apMode = true;
  WiFi.mode(WIFI_AP);
  WiFi.softAP(AP_SSID, AP_PASS);
  localIp = WiFi.softAPIP().toString();
  wifiStatus = "AP: " + String(AP_SSID);
  Serial.println("AP " + localIp);
}

// ================== NTP ==================

void setupNTP() {
  if (apMode) return;
  configTime(GMT_OFFSET, DST_OFFSET, NTP_SERVER);
  for (int i = 0; i < 20; i++) {
    delay(500);
    if (time(nullptr) >= 100000) return;
  }
}

// ================== UTILITARIOS ==================

String timeToString(time_t t) {
  if (t < 100000) return "N/A";
  struct tm* ti = localtime(&t);
  char buf[25];
  sprintf(buf, "%04d-%02d-%02d %02d:%02d:%02d", ti->tm_year + 1900, ti->tm_mon + 1, ti->tm_mday, ti->tm_hour, ti->tm_min, ti->tm_sec);
  return String(buf);
}

String getUptime() {
  unsigned long ms = millis();
  unsigned long sec = ms / 1000, min = sec / 60, hr = min / 60, days = hr / 24;
  return String(days) + "d " + String(hr % 24) + "h " + String(min % 60) + "m";
}

String jsonEscape(String s) {
  s.replace("\\", "\\\\"); s.replace("\"", "\\\""); s.replace("\n", "\\n"); s.replace("\r", "\\r"); s.replace("\t", "\\t");
  return s;
}

float calcDistance(float lat1, float lng1, float lat2, float lng2) {
  const float R = 6371000.0;
  float dLat = (lat2 - lat1) * PI / 180.0, dLng = (lng2 - lng1) * PI / 180.0;
  float a = sin(dLat / 2) * sin(dLat / 2) + cos(lat1 * PI / 180.0) * cos(lat2 * PI / 180.0) * sin(dLng / 2) * sin(dLng / 2);
  return R * 2 * atan2(sqrt(a), sqrt(1 - a));
}

// ================== BUFFER ==================

void addToBuffer() {
  if (bufferIndex >= configBufferSize || bufferIndex >= MAX_BUFFER) { bufferReady = true; return; }
  buffer[bufferIndex].pm1p0 = currentPm1p0;
  buffer[bufferIndex].pm2p5 = currentPm2p5;
  buffer[bufferIndex].pm10p0 = currentPm10p0;
  buffer[bufferIndex].lat = currentLat;
  buffer[bufferIndex].lng = currentLng;
  time_t now = time(nullptr);
  buffer[bufferIndex].timeStr = (now >= 100000) ? timeToString(now) : String(millis());
  bufferIndex++;
  hasLastBufferedPos = true;
  lastBufferedLat = currentLat;
  lastBufferedLng = currentLng;
  if (bufferIndex >= configBufferSize || bufferIndex >= MAX_BUFFER) bufferReady = true;
}

// ================== TAGO IO ==================

void sendToTagoIO() {
  if (WiFi.status() != WL_CONNECTED) { tagoFailCount++; return; }
  HTTPClient http;
  http.begin(TAGO_URL);
  http.addHeader("Content-Type", "application/json");
  http.addHeader("Device-Token", configTagoToken);

  DynamicJsonDocument doc(65536);
  JsonArray arr = doc.to<JsonArray>();
  for (int i = 0; i < bufferIndex; i++) {
    JsonObject pm1 = arr.createNestedObject(); pm1["variable"] = "pm1p0"; pm1["value"] = buffer[i].pm1p0; pm1["unit"] = "ug/m3"; pm1["time"] = buffer[i].timeStr;
    JsonObject pm25 = arr.createNestedObject(); pm25["variable"] = "pm2p5"; pm25["value"] = buffer[i].pm2p5; pm25["unit"] = "ug/m3"; pm25["time"] = buffer[i].timeStr;
    JsonObject pm10 = arr.createNestedObject(); pm10["variable"] = "pm10p0"; pm10["value"] = buffer[i].pm10p0; pm10["unit"] = "ug/m3"; pm10["time"] = buffer[i].timeStr;
    if (buffer[i].lat != 0 && buffer[i].lng != 0) {
      JsonObject lat = arr.createNestedObject(); lat["variable"] = "lat"; lat["value"] = buffer[i].lat; lat["unit"] = "lat"; lat["time"] = buffer[i].timeStr;
      JsonObject lng = arr.createNestedObject(); lng["variable"] = "lng"; lng["value"] = buffer[i].lng; lng["unit"] = "lng"; lng["time"] = buffer[i].timeStr;
    }
  }

  String payload;
  serializeJson(doc, payload);

  int httpCode = http.POST(payload);
  if (httpCode > 0 && httpCode < 400) { tagoSuccessCount++; tagoConnected = true; }
  else { tagoFailCount++; tagoConnected = false; }
  http.end();
}

// ================== AP WEB ==================

void handleApRoot() {
  String html = "<!DOCTYPE html><html><head><meta charset=\"UTF-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
    "<title>ParticulaGPS</title><style>"
    "*{margin:0;padding:0;box-sizing:border-box}body{background:#0d1117;color:#c9d1d9;font-family:sans-serif;padding:20px;max-width:400px;margin:0 auto}"
    "h1{color:#58a6ff;font-size:1.2em;border-bottom:1px solid #30363d;padding-bottom:8px;margin-bottom:16px}"
    "label{display:block;font-size:0.8em;color:#8b949e;margin:12px 0 4px}"
    "input{width:100%;padding:10px;background:#0d1117;border:1px solid #30363d;border-radius:6px;color:#f0f6fc;font-size:1em}"
    "button{width:100%;padding:12px;background:#238636;border:1px solid #238636;border-radius:6px;color:#fff;font-size:1em;font-weight:600;cursor:pointer;margin-top:16px}"
    "</style></head><body>"
    "<h1>ParticulaGPS</h1>"
    "<form action=\"/save\" method=\"GET\">"
    "<label>SSID</label><input type=\"text\" name=\"ssid\" required>"
    "<label>Senha</label><input type=\"password\" name=\"pass\">"
    "<button type=\"submit\">Salvar</button></form></body></html>";
  httpServer.send(200, "text/html", html);
}

void handleApSave() {
  if (!httpServer.hasArg("ssid")) { httpServer.send(400, "text/plain", "no ssid"); return; }
  String ssid = httpServer.arg("ssid");
  String pass = httpServer.hasArg("pass") ? httpServer.arg("pass") : "";
  prefs.begin(PREF_WIFI, false);
  prefs.putString(PREF_SSID, ssid);
  prefs.putString(PREF_PASS, pass);
  prefs.end();
  String html = "<html><body style=\"background:#0d1117;color:#c9d1d9;padding:20px;text-align:center\">"
    "<h2 style=\"color:#3fb950\">OK</h2><p>Conecte a rede: <strong>" + ssid + "</strong></p></body></html>";
  httpServer.send(200, "text/html", html);
  delay(1000);
  ESP.restart();
}
