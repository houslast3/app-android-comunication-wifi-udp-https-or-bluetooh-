#include <BLEDevice.h>
#include <BLEUtils.h>
#include <BLEServer.h>
#include <ArduinoJson.h>
#include <Wire.h>
#include <SensirionI2cSps30.h>

#define SERVICE_UUID     "6e400001-b5a3-f393-e0a9-e50e24dcca9e"
#define DATA_CHAR_UUID   "6e400002-b5a3-f393-e0a9-e50e24dcca9e"
#define CONFIG_CHAR_UUID "6e400003-b5a3-f393-e0a9-e50e24dcca9e"

// --- PMS / SPS30 ---
SensirionI2cSps30 sps30;
bool pmsConnected = false;
float pm1p0 = 0, pm2p5 = 0, pm10p0 = 0;

// --- BME280 ---
#define BME280_ADDR 0x76
struct { uint16_t dig_T1; int16_t dig_T2, dig_T3; uint16_t dig_P1; int16_t dig_P2, dig_P3, dig_P4, dig_P5, dig_P6, dig_P7, dig_P8, dig_P9; uint8_t dig_H1; int16_t dig_H2; uint8_t dig_H3; int16_t dig_H4, dig_H5; int8_t dig_H6; } bmeCal;
int32_t t_fine;
bool bmeConnected = false;
float temp = 0, hum = 0, press = 0;

// --- ENS160 ---
#define ENS160_ADDR_A 0x53
#define ENS160_ADDR_B 0x52
#define ENS160_REG_OPMODE 0x10
#define ENS160_REG_DATA_STATUS 0x20
#define ENS160_REG_DATA_AQI 0x21
#define ENS160_REG_DATA_TVOC 0x22
#define ENS160_REG_DATA_ECO2 0x24
#define ENS160_OPMODE_IDLE 0x01
#define ENS160_OPMODE_STANDARD 0x02
int ensAddr = 0;
bool ensConnected = false;
int tvoc = 0, eco2 = 0, aqi = 0;

// --- Battery ---
#define BAT_PIN 34
float batteryVoltage = 0;

// --- BLE ---
BLECharacteristic *pDataChar;
BLECharacteristic *pConfigChar;
bool deviceConnected = false;
bool oldDeviceConnected = false;
unsigned long lastSendTime = 0;
unsigned long sendInterval = 3000;
unsigned long startTime = 0;
unsigned long lastContactTime = 0;
unsigned long lastAdvCheck = 0;
StaticJsonDocument<512> configDoc;
bool configLoaded = false;

// ========== BME280 FUNCTIONS ==========
float compT(int32_t adc_T) {
  int32_t v1 = ((((adc_T>>3)-((int32_t)bmeCal.dig_T1<<1))*((int32_t)bmeCal.dig_T2))>>11);
  int32_t v2 = (((((adc_T>>4)-((int32_t)bmeCal.dig_T1))*((adc_T>>4)-((int32_t)bmeCal.dig_T1)))>>12)*((int32_t)bmeCal.dig_T3))>>14;
  t_fine = v1+v2;
  return (float)((t_fine*5+128)>>8)/100.0;
}
float compP(int32_t adc_P) {
  int64_t v1=((int64_t)t_fine)-128000, v2=v1*v1*(int64_t)bmeCal.dig_P6;
  v2=v2+((v1*(int64_t)bmeCal.dig_P5)<<17); v2=v2+(((int64_t)bmeCal.dig_P4)<<35);
  v1=((v1*v1*(int64_t)bmeCal.dig_P3)>>8)+((v1*(int64_t)bmeCal.dig_P2)<<12);
  v1=(((((int64_t)1)<<47)+v1))*((int64_t)bmeCal.dig_P1)>>33;
  if(v1==0)return 0;
  int64_t p=1048576-adc_P; p=(((p<<31)-v2)*3125)/v1;
  v1=(((int64_t)bmeCal.dig_P9)*(p>>13)*(p>>13))>>25;
  v2=(((int64_t)bmeCal.dig_P8)*p)>>19;
  p=((p+v1+v2)>>8)+(((int64_t)bmeCal.dig_P7)<<4);
  return (float)p/256.0/100.0;
}
float compH(int32_t adc_H) {
  int32_t v=((t_fine-((int32_t)76800)));
  v=(((((adc_H<<14)-(((int32_t)bmeCal.dig_H4)<<20)-(((int32_t)bmeCal.dig_H5)*v))+((int32_t)16384))>>15)*(((((((v*((int32_t)bmeCal.dig_H6))>>10)*(((v*((int32_t)bmeCal.dig_H3))>>11)+((int32_t)32768)))>>10)+((int32_t)2097152))*((int32_t)bmeCal.dig_H2)+8192)>>14));
  v=(v-((((v>>15)*(v>>15))>>7)*((int32_t)bmeCal.dig_H1))>>4);
  v=(v<0?0:v); v=(v>419430400?419430400:v);
  return (float)(v>>12)/1024.0;
}
void bmeReadCal() {
  uint8_t d[26]; Wire.beginTransmission(BME280_ADDR); Wire.write(0x88); Wire.endTransmission(); Wire.requestFrom(BME280_ADDR,24);
  for(int i=0;i<24;i++)d[i]=Wire.read();
  bmeCal.dig_T1=(d[1]<<8)|d[0]; bmeCal.dig_T2=(d[3]<<8)|d[2]; bmeCal.dig_T3=(d[5]<<8)|d[4];
  bmeCal.dig_P1=(d[7]<<8)|d[6]; bmeCal.dig_P2=(d[9]<<8)|d[8]; bmeCal.dig_P3=(d[11]<<8)|d[10];
  bmeCal.dig_P4=(d[13]<<8)|d[12]; bmeCal.dig_P5=(d[15]<<8)|d[14]; bmeCal.dig_P6=(d[17]<<8)|d[16];
  bmeCal.dig_P7=(d[19]<<8)|d[18]; bmeCal.dig_P8=(d[21]<<8)|d[20]; bmeCal.dig_P9=(d[23]<<8)|d[22];
  Wire.beginTransmission(BME280_ADDR); Wire.write(0xA1); Wire.endTransmission(); Wire.requestFrom(BME280_ADDR,1); bmeCal.dig_H1=Wire.read();
  Wire.beginTransmission(BME280_ADDR); Wire.write(0xE1); Wire.endTransmission(); Wire.requestFrom(BME280_ADDR,7);
  for(int i=0;i<7;i++)d[i]=Wire.read();
  bmeCal.dig_H2=(d[1]<<8)|d[0]; bmeCal.dig_H3=d[2]; bmeCal.dig_H4=(d[3]<<4)|(d[4]&0x0F); bmeCal.dig_H5=(d[5]<<4)|(d[4]>>4); bmeCal.dig_H6=(int8_t)d[6];
}
void bmeConfig() {
  Wire.beginTransmission(BME280_ADDR); Wire.write(0xF2); Wire.write(0x01); Wire.endTransmission();
  Wire.beginTransmission(BME280_ADDR); Wire.write(0xF4); Wire.write(0x27); Wire.endTransmission();
}

// ========== ENS160 FUNCTIONS ==========
bool ensVerify(int addr) {
  Wire.beginTransmission(addr); if(Wire.endTransmission()!=0)return false;
  Wire.beginTransmission(addr); Wire.write(0x00); Wire.endTransmission(); Wire.requestFrom(addr,2);
  if(Wire.available()==2){uint16_t id=(Wire.read())|(Wire.read()<<8);return id==0x0160;}
  return false;
}
void ensSetMode(int addr, byte mode) { Wire.beginTransmission(addr); Wire.write(ENS160_REG_OPMODE); Wire.write(mode); Wire.endTransmission(); delay(20); }

// ========== SENSOR INIT ==========
void initSensors() {
  Serial.println("[INIT] Inicializando I2C (SDA=21, SCL=22)...");
  Wire.begin(21, 22); Wire.setClock(100000);

  // SPS30
  Serial.println("[PMS] Procurando SPS30 no I2C...");
  for(uint8_t addr : {SPS30_I2C_ADDR_69, 0x68, 0x6A}){
    sps30.begin(Wire, addr);
    int16_t err=sps30.stopMeasurement(); delay(50);
    if(err==0){err=sps30.startMeasurement(SPS30_OUTPUT_FORMAT_OUTPUT_FORMAT_FLOAT); if(err==0){pmsConnected=true; Serial.print("[PMS] SPS30 encontrado em 0x"); Serial.println(addr,HEX); break;}}
  }
  if(!pmsConnected) Serial.println("[PMS] SPS30 NAO encontrado");

  // BME280
  Serial.println("[BME] Procurando BME280...");
  Wire.beginTransmission(BME280_ADDR);
  if(Wire.endTransmission()==0){bmeReadCal(); bmeConfig(); bmeConnected=true; Serial.println("[BME] BME280 encontrado em 0x76");}
  else Serial.println("[BME] BME280 NAO encontrado");

  // ENS160
  Serial.println("[ENS] Procurando ENS160...");
  if(ensVerify(ENS160_ADDR_A)){ensAddr=ENS160_ADDR_A; ensConnected=true;}
  else if(ensVerify(ENS160_ADDR_B)){ensAddr=ENS160_ADDR_B; ensConnected=true;}
  if(ensConnected){ensSetMode(ensAddr, ENS160_OPMODE_STANDARD); Serial.println("[ENS] ENS160 encontrado e configurado");}
  else Serial.println("[ENS] ENS160 NAO encontrado");
}

// ========== SENSOR READ ==========
void readSensors() {
  // SPS30
  if(pmsConnected){
    uint16_t ready=0;
    if(sps30.readDataReadyFlag(ready)==0 && ready>0){
      float mc1p0,mc2p5,mc4p0,mc10p0,nc0p5,nc1p0,nc2p5,nc4p0,nc10p0,tps;
      if(sps30.readMeasurementValuesFloat(mc1p0,mc2p5,mc4p0,mc10p0,nc0p5,nc1p0,nc2p5,nc4p0,nc10p0,tps)==0){
        pm1p0=mc1p0; pm2p5=mc2p5; pm10p0=mc10p0;
        Serial.printf("[PMS] PM1=%.1f PM2.5=%.1f PM10=%.1f\n",pm1p0,pm2p5,pm10p0);
      }
    }
  }

  // BME280
  if(bmeConnected){
    Wire.beginTransmission(BME280_ADDR); Wire.write(0xF7); Wire.endTransmission(); Wire.requestFrom(BME280_ADDR,8);
    if(Wire.available()==8){
      uint32_t p_msb=Wire.read(),p_lsb=Wire.read(),p_xlsb=Wire.read(),t_msb=Wire.read(),t_lsb=Wire.read(),t_xlsb=Wire.read(),h_msb=Wire.read(),h_lsb=Wire.read();
      int32_t adc_T=(t_msb<<12)|(t_lsb<<4)|(t_xlsb>>4), adc_P=(p_msb<<12)|(p_lsb<<4)|(p_xlsb>>4), adc_H=(h_msb<<8)|h_lsb;
      temp=compT(adc_T); press=compP(adc_P); hum=compH(adc_H);
      Serial.printf("[BME] Temp=%.1fC Hum=%.1f%% Press=%.1fhPa\n",temp,hum,press);
    }
  }

  // ENS160
  if(ensConnected){
    Wire.beginTransmission(ensAddr); Wire.write(ENS160_REG_DATA_STATUS); Wire.endTransmission(); Wire.requestFrom(ensAddr,1); byte status=Wire.available()?Wire.read():0;
    Wire.beginTransmission(ensAddr); Wire.write(0x26); Wire.endTransmission(); Wire.requestFrom(ensAddr,1); byte misc=Wire.available()?Wire.read():0;
    if(((misc>>2)&0x03)==0){ // normal operation
      Wire.beginTransmission(ensAddr); Wire.write(ENS160_REG_DATA_TVOC); Wire.endTransmission(); Wire.requestFrom(ensAddr,2); byte t_l=Wire.read(),t_h=Wire.read(); tvoc=(t_h<<8)|t_l;
      Wire.beginTransmission(ensAddr); Wire.write(ENS160_REG_DATA_ECO2); Wire.endTransmission(); Wire.requestFrom(ensAddr,2); byte e_l=Wire.read(),e_h=Wire.read(); eco2=(e_h<<8)|e_l;
      Wire.beginTransmission(ensAddr); Wire.write(ENS160_REG_DATA_AQI); Wire.endTransmission(); Wire.requestFrom(ensAddr,1); aqi=Wire.available()?Wire.read():0;
      Serial.printf("[ENS] TVOC=%d eCO2=%d AQI=%d\n",tvoc,eco2,aqi);
    }
  }

  // Battery
  int adcVal = 0;
  for(int i=0;i<8;i++) adcVal += analogRead(BAT_PIN);
  adcVal /= 8;
  batteryVoltage = (adcVal/4095.0)*3.3*2.0; // voltage divider 1:1 (100k+100k)
  Serial.printf("[BAT] ADC=%d V=%.2f\n",adcVal,batteryVoltage);
}

// ========== BLE CALLBACKS ==========
class ServerCallbacks: public BLEServerCallbacks {
  void onConnect(BLEServer* pServer) { deviceConnected=true; lastContactTime=millis(); Serial.println("[BLE] CONECTOU!"); }
  void onDisconnect(BLEServer* pServer) { deviceConnected=false; Serial.println("[BLE] DESCONECTOU!"); BLEDevice::startAdvertising(); Serial.println("[BLE] Advertising reiniciado"); }
};

class ConfigCallbacks: public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic *pChar) {
    String value = pChar->getValue();
    if(value.length()>0){
      DeserializationError err = deserializeJson(configDoc, value.c_str());
      if(!err){
        if(configDoc.containsKey("interval")){sendInterval=(unsigned long)configDoc["interval"]; Serial.printf("[CFG] Intervalo=%lu\n",sendInterval);}
        configLoaded=true;
      }
    }
  }
  void onRead(BLECharacteristic *pChar) {
    configDoc["interval"]=sendInterval; String out; serializeJson(configDoc,out); pChar->setValue(out);
  }
};

// ========== SEND ==========
void sendSensorData() {
  if(!deviceConnected)return;
  StaticJsonDocument<768> doc;
  if(pmsConnected){doc["pm1p0"]=pm1p0; doc["pm2p5"]=pm2p5; doc["pm10p0"]=pm10p0;}
  if(bmeConnected){doc["temp"]=temp; doc["hum"]=hum; doc["press"]=press;}
  if(ensConnected){doc["tvoc"]=tvoc; doc["eco2"]=eco2; doc["aqi"]=aqi;}
  doc["bat"]=batteryVoltage;
  doc["uptime"]=(millis()-startTime)/1000;
  String json; serializeJson(doc,json);
  Serial.printf("[SEND] %d bytes: %s\n",json.length(),json.c_str());
  pDataChar->setValue(json);
  pDataChar->notify();
  lastContactTime=millis();
}

// ========== SETUP ==========
void setup() {
  Serial.begin(115200); delay(500);
  Serial.println("\n========== ParticulaGPS BLE v3.0 ==========");
  startTime=millis(); initSensors();

  BLEDevice::init("ParticulaGPS-BLE");
  BLEServer *pServer=BLEDevice::createServer(); pServer->setCallbacks(new ServerCallbacks());
  BLEService *pService=pServer->createService(SERVICE_UUID);
  pDataChar=pService->createCharacteristic(DATA_CHAR_UUID, BLECharacteristic::PROPERTY_NOTIFY);
  pConfigChar=pService->createCharacteristic(CONFIG_CHAR_UUID, BLECharacteristic::PROPERTY_READ|BLECharacteristic::PROPERTY_WRITE);
  pConfigChar->setCallbacks(new ConfigCallbacks());
  pService->start();
  BLEAdvertising *pAdvertising=BLEDevice::getAdvertising();
  pAdvertising->addServiceUUID(SERVICE_UUID); pAdvertising->setScanResponse(true);
  pAdvertising->setMinPreferred(0x06); pAdvertising->setMaxPreferred(0x12);
  BLEDevice::startAdvertising();
  Serial.println("[BLE] Advertising: ParticulaGPS-BLE\n========================================");
}

void loop() {
  unsigned long now=millis();
  if(deviceConnected && now-lastSendTime>=sendInterval){lastSendTime=now; readSensors(); sendSensorData();}
  if(!deviceConnected && oldDeviceConnected){delay(500); BLEDevice::startAdvertising(); oldDeviceConnected=false;}
  if(deviceConnected && !oldDeviceConnected){oldDeviceConnected=true;}
  if(!deviceConnected && now-lastAdvCheck>10000){lastAdvCheck=now; Serial.println("[BLE] Aguardando conexao...");}
  delay(10);
}
